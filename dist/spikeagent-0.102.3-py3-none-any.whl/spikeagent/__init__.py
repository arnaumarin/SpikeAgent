"""SpikeAgent - AI-powered assistant for spike sorting and neural data analysis."""

__version__ = "0.102.3"

